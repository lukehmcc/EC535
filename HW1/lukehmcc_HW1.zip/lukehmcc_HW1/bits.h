#ifndef BITS_H
#define BITS_H

unsigned int BinaryMirror(unsigned int);
unsigned int CountSequence(unsigned int);
char *UIntToBinary(unsigned int);
char *UIntToAscii(unsigned int);

#endif // BITS_H
