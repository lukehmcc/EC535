#!/bin/sh
./qsort_large input_large.dat > output_large.txt
